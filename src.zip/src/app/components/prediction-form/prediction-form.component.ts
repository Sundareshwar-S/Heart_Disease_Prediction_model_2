import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ResultsViewComponent } from '../results-view/results-view.component';

@Component({
  standalone: true,
  selector: 'app-prediction-form',
  templateUrl: './prediction-form.component.html',
  styleUrls: ['./prediction-form.component.css'],
  imports: [CommonModule, FormsModule, ResultsViewComponent] // ✅ This line is critical
})
export class PredictionFormComponent {
  formData = {
    user: '',
    password: '',
    host: '',
    database_name: '',
    table_name: ''
  };

  errorMsg = '';
  results: any[] = [];

  submitForm() {
  const url = 'http://localhost:5001/api/predict';

  fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(this.formData)
  })
    .then(response => {
      if (!response.ok) {
        throw new Error('Server returned an error');
      }
      return response.json();
    })
    .then(data => {
      if (data.error) {
        this.errorMsg = data.error;
        this.results = [];
      } else {
        this.results = data.data;
        this.errorMsg = '';
      }
    })
    .catch(error => {
      this.errorMsg = 'An error occurred: ' + error.message;
      this.results = [];
    });
}
}
