import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-results-view',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './results-view.component.html',
  styleUrls: ['./results-view.component.css']
})
export class ResultsViewComponent {
  @Input() results: any[] = [];

  columns: string[] = [
  "Name",
  "Age",
  "Sex",
  "Chest Pain Type",
  "Bp",
  "Cholesterol",
  "Fbs Over 120",
  "Ekg Results",
  "Max Hr",
  "Exercise Angina",
  "St Depression",
  "Slope Of St",
  "Number Of Vessels Fluro",
  "Thallium",
  "Heart Disease Probability",
  "Predicted Outcome"
];
}
